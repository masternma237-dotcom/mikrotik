# Architecture — Guide Interactif MikroTik (v1.2)

Application 100 % statique (HTML/CSS/JS vanilla), sans build ni backend.

```
index.html              coquille HTML + CSP + ordre de chargement des scripts
css/styles.css          tous les styles (thèmes clair/sombre, responsive, print)
js/registry.js          registre global MK (parcours, niveaux, API d'enregistrement)  ← 1er chargé
data/*.js               contenu : sections, glossaire, schémas (un fichier par module)
js/diagrams.js          helpers SVG + schémas du parcours Socle
js/app.js               moteur : navigation, rendu, recherche, thème, export PDF       ← dernier chargé
tools/validate.js       contrôle de cohérence des données (node tools/validate.js)
```

## Ajouter une section

1. Choisir un parcours (`track`) parmi ceux de `MK.tracks` : `socle`, `securite`,
   `services`, `interconnexion`, `exploitation`.
2. Créer (ou compléter) un fichier `data/<parcours>.js` :

```js
(function () {
  const R = String.raw;               // blocs CLI : les « \ » RouterOS restent intacts
  MK.addSections([{
    id: "mon-module",                 // kebab-case, unique, STABLE (sert aux liens #id et à la progression)
    track: "services",
    level: "intermediaire",           // debutant | intermediaire | avance
    title: "Titre affiché",
    icon: "fa-solid fa-server",       // Font Awesome 6 (gratuit)
    step: "17",                       // numéro affiché, unique
    requires: ["firewall"],           // optionnel : ids de sections prérequises
    description: "Texte sans chevrons < >.",
    cliCommands: [ R`# 1. Titre\n/ip ...` ],
    winboxSteps: [ "<span class='wb-path'>IP → ...</span> → ..." ],
    diagram: "mon-schema",            // clé enregistrée via MK.addDiagrams
    terminology: ["Terme A"],         // doivent exister dans le glossaire
    concepts: [ { term: "...", def: "..." } ],
    alerts: [ { type: "warning|info|success", icon: "fa-triangle-exclamation", text: "..." } ],
    table: { headers: ["A", "B"], rows: [["1", "2"]] }
  }]);
})();
```

3. Ajouter les définitions : `MK.addGlossary({ "Terme A": "Définition." })`.
4. Ajouter le schéma : `MK.addDiagrams({ "mon-schema": () => \`<div class="diagram-placeholder"><svg …>…</svg><p>légende</p></div>\` })`
   (helpers : `svgBox`, `svgArrow`, `svgArrowRed`, `svgLine`).
5. Déclarer le fichier dans `index.html` (entre `registry.js` et `diagrams.js`/`app.js`).
6. Lancer `node tools/validate.js` — il doit afficher 0 erreur.

## Champs optionnels d'une section (v2.0)

- `steps: ["HTML…"]` : déroulé numéroté (liens internes `<a href="#id-de-section">` autorisés).
- `checklist: ["HTML…"]` : critères de réussite cochables, mémorisés par section dans `mk-checks`.
- `tool: "id"` : outil interactif monté dans la page (voir ci-dessous).
- Quiz : `MK.addQuiz({ "id-section": [[question, [options], indexBonneReponse, explication], …] })` dans un fichier
  `data/quiz-*.js` ; chaque section de contenu doit avoir au moins 2 questions (contrôlé par le validateur).

## Version, service worker et publication

La version vit à UN seul endroit : `MK.version` dans `js/registry.js`. Avant chaque publication :

```
node tools/validate.js         # données, quiz, liens, manifeste, CSP, sw.js à jour
node tools/test-generator.js   # générateur .rsc
node tools/build-sw.js         # régénère sw.js (liste de pré-cache + version du cache)
```

Le mode hors ligne exige HTTPS ou localhost. Sur Nginx, déclarer le type MIME du manifeste :
`types { application/manifest+json webmanifest; }` (ou `include mime.types;` mis à jour).

## Ajouter un outil interactif

1. Créer `js/tools/mon-outil.js` : une fonction `mount(host)` qui construit l'interface dans l'élément fourni,
   et, si possible, une fonction pure testable sous Node (voir `rsc-generator.js` + `tools/test-generator.js`).
2. L'enregistrer : `MK.addTool('mon-outil', { title: 'Titre', mount })`.
3. Déclarer la balise `<script>` dans `index.html` juste après `js/registry.js`.
4. Dans la section : `tool: "mon-outil"`, `cliCommands: []` (le validateur vérifie que l'outil existe).
5. Règles : aucun réseau, aucun stockage de saisies sensibles, validation par liste blanche, échappement
   des secrets, pas de `innerHTML` avec des données saisies par l'utilisateur.

## Règles à respecter

- **Placeholders** : dans les blocs CLI, écrire `<MOT_DE_PASSE_FORT>` tel quel ; dans les
  textes HTML (alertes, concepts, tableaux) écrire `&lt;MOT_DE_PASSE_FORT&gt;`.
  Aucun mot de passe réel dans les exemples.
- **Description** : pas de chevrons (elle est réutilisée par l'export PDF).
- **Identifiants** : ne jamais renommer un `id` publié (la progression des apprenants y est liée).
- **Scripts** : aucun code inline ni `onclick=` (la CSP interdit `'unsafe-inline'` pour les scripts) ;
  utiliser `data-*` et la délégation d'événements dans `js/app.js`.
- **Ordre des parcours** : celui de `MK.tracks` ; à l'intérieur d'un parcours, l'ordre de chargement.

## Feuille de route (lots validés)

| Lot | Fichiers prévus | Contenu |
|---|---|---|
| v1.2 ✔ | `securite-*.js` | Safe Mode, anti-brute force, RAW, anti-scan/DoS, durcissement, sauvegarde auto |
| v1.3 ✔ | `services-*.js` | NAT avancé, DNS, NTP, DHCP avancé, QoS (simple queue + PCQ) |
| v1.4 ✔ | `interconnexion-*.js` | WireGuard (accès distant, site-à-site), IPsec IKEv2, failover, PCC multi-WAN |
| v1.5 ✔ | `exploitation-*.js`, `js/tools/` | Logs / syslog, alertes, SNMP + Zabbix, API REST, générateur .rsc |
| v2.0 ✔ | `labs.js`, `quiz-*.js`, `sw.js`, `interconnexion-3.js`, `services-3.js` | Labs, quiz, mode hors ligne, OSPF/BGP, CAPsMAN, marque |
